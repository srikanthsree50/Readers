const {Schema,model} = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

    const readerSchema = new Schema({
    email: {
        type: String,
        unique:true,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    books: [{ 
        type: Schema.Types.ObjectId, 
        ref:'Book'
    }]
});

readerSchema.plugin(uniqueValidator);
module.exports = model("Reader",readerSchema);