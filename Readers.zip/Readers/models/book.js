const {Schema,model} = require('mongoose');

    const bookSchema = new Schema({
    bookName: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    publishedDate: {
        type: Date,
        required: true,
        default:Date.now
    },
    readerId: [{ 
        type: Schema.Types.ObjectId, 
        ref:'Reader'
    }]
});

module.exports = model("Book",bookSchema);