const jwt = require('jsonwebtoken');

module.exports = (req,res,next) =>{
    try{
const token = req.headers.authorization.split(" ")[0];
const decodedToken = jwt.verify(token,'secret');
req.userData = {email:decodedToken.email,readerId:decodedToken.readerId}
next(); 
    }
    catch(err){
return res.status(401).json({
    message:'unauthenticated user access denied...'
})
    }
}