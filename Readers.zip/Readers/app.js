const path = require('path');
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const { connect } = require('mongoose');
const cookieParser = require('cookie-parser');
const mongoDBStore = require('connect-mongodb-session')(session);
const Url = 'mongodb://localhost:27017/BookDB';
const port = process.env.PORT || 3000;

const app = express();
const readerRoute = require('./routes/reader');
const adminRoute = require('./routes/admin');
const Reader = require('./models/reader');

let store = new mongoDBStore({
  uri:Url,
  collection:'sessions'
});
app.use(cookieParser());
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(path.join('public')));

let secretKey = 'mysecret'
app.use(session({
  secret:secretKey,
  resave:true,
  saveUninitialised:true,
  store:store
}))

app.use((req,res,next) => {
  if(!req.session.reader){
    return next();
  }
  Reader.findOne(req.session.reader._id)
  .then( reader => {
    req.reader=reader;
    next();
  })
  .catch(err =>{
return res.status(500).json({
    message:'reader session not availabe'
})
  })
})

app.use((req,res,next) => {
 res.locals.userData = req.userData || null;
 next();
 //res.locals.reader = req.reader;
})

app.use((req,res,next) => {
    res.setHeader("Access-Control-Allow-Origin","*");
    res.setHeader("Access-Control-Allow-Headers","Origin,X-Requested-with,Authorization,Content-Type,Accept");
    res.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,PATCH,DELETE,OPTIONS");
    next();
})
app.use('/api/reader',readerRoute)
app.use('/api/admin',adminRoute)

const startApp = async () => {
  try{
await connect(Url, {
useFindAndModify: false,
useUnifiedTopology: true,
useNewUrlParser: true,
useCreateIndex: true
});
console.log('successfully connected to database...');

app.listen(port,() => {
  console.log(`Server started Successfully on Port : ${port}`);
})

  }
  catch(err){
console.log(err);
  }
}

startApp();