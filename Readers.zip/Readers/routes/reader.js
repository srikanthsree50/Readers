const router = require('express').Router();
const { signUp, login, logOut,getBookByReader } = require('../controllers/reader')

router.post('/signup', async (req,res) => {
    await signUp(req,res);
});

router.post('/login', async (req,res) => {
  await  login(req,res);
});

router.post('/logout', async (req,res) => {
   await logOut(req,res);
})

router.get('/book', async (req,res) => {
    await getBookByReader(req,res);
});

module.exports = router; 