const router = require('express').Router();
const { getBookById, getBooks, addBook, updateBook, deleteBook } = require('../controllers/admin')

router.get('/:id', async (req,res) => {
    await getBookById(req,res);
});

router.get('/', async (req,res) => {
  await  getBooks(req,res);
});

router.post('/', async (req,res) => {
   await addBook(req,res);
})

router.put('/:id', async (req,res) => {
    await updateBook(req,res);
});

router.delete('/:id', async (req,res) => {
    await deleteBook(req,res);
});

module.exports = router; 