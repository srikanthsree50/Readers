const brcypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Reader = require('../models/reader')
const Book = require('../models/book');



const signUp = (req, res) => {
    bcrypt.hash(req.body.password, 10).then(hash => {
      const reader = new Reader({
        email: req.body.email,
        password: hash
      });
      reader
        .save()
        .then(result => {
          res.status(201).json({
            message: "Reader signup successfull ",
            result: result
          });
        })
        .catch(err => {
          res.status(500).json({
            message: "Invalid authentication credentials!"
          });
        });
    });
  }
  

const login = (req, res) => {
    let fetchedReader;
    Reader.findOne({ email: req.body.email })
      .then(reader => {
        if (!reader) {
          return res.status(401).json({
            message: "Auth failed"
          });
        }
        fetchedReader = reader;
        return bcrypt.compare(req.body.password, reader.password);
      })
      .then(result => {
        if (!result) {
          return res.status(401).json({
            message: "Auth failed"
          });
        }
        const token = jwt.sign(
          { email: fetchedReader.email, userId: fetchedReader._id },
          "secret_this_should_be_longer",
          { expiresIn: "1h" }
        );
        res.status(200).json({
          token: token,
          expiresIn: 3600,
          readerId: fetchedReader._id
        });
      })
      .catch(err => {
        return res.status(401).json({
          message: "Invalid authentication credentials!"
        });
      });
  }

const logOut = (req,res) =>{
    req.session.destroy(err =>{
        if(err){
            return res.status(500).json({
                message: "cannot logout session please try later!"
              });
        }
        return res.status(401).json({
            message: "Reader logged out successfully..."
          });
    })
}

const getBookByReader = async(req,res) => {
    try{
    
const book = await Book.findOne({_id:req.body.bookId});
if(book){
    return res.status(200).json({
        book,
        message: 'book fetched successfully..',
        success:true
    });
}
return res.status(404).json({
    message: 'book not found ',
    success:false
});
    }
    catch(err){
return res.status(500).json({
    message:err.message,
    success:false
})
    }
}

module.exports ={
    signUp,
    login,
    logOut,
    getBookByReader
}