const Book = require('../models/book');

const getBookById = async(req,res) => {
    try{
    
const book = await Book.findById(req.params.id);
if(book){
    return res.status(200).json({
        book,
        message: 'book fetched successfully..',
        success:true
    });
}
return res.status(404).json({
    message: 'book not found ',
    success:false
});
    }
    catch(err){
return res.status(500).json({
    message:err.message,
    success:false
})
    }
}
    
    const getBooks = async(req,res) => {
        try {

const [books] = await Promise.all([Book.find({}).exec()]);

if(books){
    return res.status(201).json({
        object:"list",
        data: books,
        message:' books fetched successfully...',
        success:true
    });
}
return res.status(404).json({
    message: 'books not found ',
    success:false
});
        }
        catch(err){
            return res.status(500).json({
                message:err.message,
                success:false
            })
        }
    }


const addBook = async (req,res) => {
return new Promise(async(resolve,reject) => {

    try{
        const book = new Book({
            bookName:req.body.bookName,
            author:req.body.author,
            publishedDate:req.body.publishedDate,
            readerId:req.userData.readerId
        });

    const newbook  = await book.save();
    return res.status(201).json({
        message:'book created successfully',
        success:true
    });
    }
    catch(err){
        reject(err);
       return res.status(500).json({
            message:err.message,
            success:false
        })
    }
})
}


const updateBook = async(req,res) => {
try {
    
await Book.findByIdAndUpdate(req.params.id,req.body);
 
return res.status(201).json({
    message:'book updated successfully',
    success:true
});
}
catch(err){
    return res.status(500).json({
        message:err.message,
        success:false
    })
}
}

const deleteBook = async(req,res) => {
 try{
const book = await Book.findByIdAndDelete(req.params.id);
if(!book){
    return res.status(404).json({
        message:'book not found...',
        success:false
    })
}
return res.status(200).json({
    message:'book deleted successfully...',
    success:true
})
 }   
 catch(err){

    return res.status(500).json({
        message:err.message,
        success:false
    })
 }
}

module.exports = {
    getBookById,
    getBooks,
    addBook,
    updateBook,
    deleteBook

}